﻿namespace CaptureBody
{
    public enum Visualization
    {

        Color = 0,

        Depth = 1,

        Infrared = 3
    }

}